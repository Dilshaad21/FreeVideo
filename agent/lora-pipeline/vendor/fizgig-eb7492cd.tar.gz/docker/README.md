# Running Fizgig on a rented GPU

[**⚡ Deploy Fizgig on RunPod →**](https://console.runpod.io/deploy?type=GPU&gpu=RTX+5090&count=1&template=bdrdew7hxw&ref=vkb387ep)

Fizgig in your browser: the pod runs the app and you open it as a web page, from your computer or your phone. Training, Studio, LoRA Royale, Profiler, Extract and the sample gallery are all there. Nothing to install, and your own GPU stays free while it trains.

*That link is a referral one — it supports Fizgig's development at no extra cost to you.*

**Need the old pod?** The previous template, with the classic app in a remote desktop, stays available as **[Fizgig Classic v7.x](https://console.runpod.io/deploy?type=GPU&gpu=RTX+5090&count=1&template=faoq8ed6um&ref=vkb387ep)**: see [the classic template](#the-classic-template-remote-desktop) below. Pods you already have keep running as they are.

---

## Storage

**Give it 300 GB (the template's default), mounted at `/workspace`.** Each model's files run to tens of GB,
so a few models, your datasets and their LoRAs fill 200 GB quickly; 100 GB is the least that works for one.

Then the one thing to know: **stopping a pod keeps everything; terminating it does not.** Stop
between sessions and your models, datasets and LoRAs are all still there when you start it again.
Terminate and the disk goes with the pod.

That's it for the default **Volume Disk**, which is what the template comes with and is perfectly
fine to use.

A **Network Volume** is the upgrade if you want one: it's a separate thing that outlives any pod, so
you can terminate freely and attach the same storage to a new pod later. The catch is that it's
region-locked, and the region you create it in may not have the GPU you want — so if you can't find
a region with both, don't fight it. Take the Volume Disk and just stop rather than terminate.

**Not a Global Volume.** RunPod's newer global volumes are object storage behind a mount, not a real
filesystem: by RunPod's own documentation they can't set file permission bits, don't support file
locking or atomic rename, and aren't recommended for workloads that write heavily. Fizgig needs all
three — git can't even create the checkout there, and training writes a checkpoint every epoch. Mount
one at `/workspace` and the pod restarts every few seconds.
Use a Volume Disk or a regional Network Volume.

Either way, download the models once and every future session reuses them.

## Which GPU

The link defaults to an **RTX 5090**, and that's a deliberate choice rather than "the newest one".

Fizgig sizes Krea 2's block swap to your VRAM, and **at 32 GB it uses none at all**. Block swap
moves weights over PCIe every step and costs roughly **4× the step time**. When you're billed by the
hour, a card that's slightly dearer but four times faster is much cheaper per finished LoRA.

| | Cards | |
|---|---|---|
| **Best** | RTX 5090 (32 GB), L40S / A6000 (48 GB) | Krea 2 with no block swap |
| **Good value** | RTX 4090, 3090, A5000 (24 GB) | Swaps for Krea 2; ideal for Klein 9B |
| **Smallest worth renting** | 16 GB | Fine, but heavy swap makes it false economy by the hour |

H100 and A100 work but are poor value here — LoRA training never touches 80 GB, and you'd pay
several times more for it.

**Let Fizgig pick.** The **Rent a pod** card on the **Pods** tab of Fizgig on your own computer lists the cards RunPod has free right now (with your RunPod API key saved there), filtered by memory, cloud and a top price per hour, cheapest per run first. Tell it how long your run takes on a 5090 and each row shows roughly what the same run costs on that card. **Deploy** opens RunPod's page with that card and this template chosen; you add the volume and press Deploy there. The speeds are a rough guide from public benchmarks; the prices and stock are RunPod's own.

<p align="center"><img src="../docs/assets/screenshots/rent_a_pod.png" alt="Rent a pod: RunPod's free cards, cheapest per run first, each with Deploy" width="800"></p>

## Logging in

**Give it a few minutes first.** RunPod downloads the image before anything starts, and until then the links give you nothing even though the pod looks ready. The **Logs** tab shows the download. You're ready when the log ends with the "Ready" banner:

```
[fizgig]  Ready. Open the pod's HTTP port 8081 for Fizgig.
[fizgig]      password: ...
```

In the pod's **Connect** menu, open **HTTP port 8081** and log in with that password. There's no user name.

| | Port | Username | Password |
|---|---|---|---|
| **Fizgig** | 8081 | none | the pod's password |
| **File manager** | 8080 | `admin` | the same one* |

\* The file manager refuses very common passwords (`abc123`, `password1234`). For one of those it gets zeros added to the end, up to 12 characters, **for port 8080 only** (`abc123` becomes `abc123000000`); if it refuses that too, its login isn't set up. Fizgig's sidebar and the pod's log say which. Pick a less common password and both logins are identical.

**Choosing the password.** On the deploy screen expand **Edit Template → Environment Variables** and add `FIZGIG_PASSWORD` (12+ characters). If you don't, the pod generates one on its first start, prints it in the log, and keeps it on your volume, so it stays the same every time you stop and start the pod. If the log seems to stop short of the banner, switch to another tab and back; RunPod's log view sometimes needs a nudge.

**Opening it from Fizgig on your own computer.** With your RunPod API key saved in Fizgig's **Pods** tab, the Fizgig window opens your pod already logged in: it reads `FIZGIG_PASSWORD` from the pod's settings on RunPod each time, never saving it. That's one more reason to set `FIZGIG_PASSWORD` on the deploy screen as a plain value: a password kept as a RunPod secret, or one the pod made up, you type yourself.

<p align="center"><img src="../docs/assets/screenshots/pods.png" alt="The Pods tab: your pods and your other computers" width="800"></p>

### How the pod is secured

**Fizgig always needs a password on a pod.** There is no open mode: without `FIZGIG_PASSWORD` one is generated and printed in the log. An open Fizgig on a public URL is a shell on someone else's GPU. Wrong guesses are slowed down per visitor.

**SSH is off unless you ask for it.** Nothing listens on port 22 until `PUBLIC_KEY` is set, and then only your own key gets in. RunPod's "SSH Terminal Access" toggle sets it for you.

**Everything in the pod runs as root, deliberately.** A rented GPU has one tenant, you, and the password is what protects it. An unprivileged user would not change what a logged-in visitor can do and would break `/workspace` permissions on existing pods.

## First run

1. Open **port 8081** and log in.
2. **Preferences → ⬇ Download models for me.** Krea 2 is ~45 GB and needs no Hugging Face account; gated models (Klein, Flux 3 Image Klein) ask for a free token.
3. **Start tab → Upload a training folder**, or drag a folder into `/workspace/datasets` on **port 8080**.
4. **Training → Start.**

**Using Fizgig on your own computer too?** Its **Pods** tab opens this pod in the Fizgig window: paste the pod's ID, or add your RunPod API key and your pods appear by themselves, with Start and Stop. See [Pods](../docs/WEB_UI.md#pods-a-rented-gpu-from-your-own-fizgig).

Closing the browser tab does **not** stop training. Fizgig runs on the pod, so close the tab, come back later (from your phone if you like) and the run is still going. Finished LoRAs download from the Training tab and the gallery. More in [the web UI guide](../docs/WEB_UI.md).

## Getting files in and out

**From Fizgig on your own computer** (its Pods tab opens the pod in the Fizgig window): the Start tab's **From this computer** card sends any of your local training folders up in one click. Or upload a folder from the Start tab in any browser.

<p align="center"><img src="../docs/assets/screenshots/from_this_computer.png" alt="From this computer: your own training folders on the pod's page, ready to send" width="800"></p>

**Port 8080** is a file manager rooted at `/workspace`: the **File manager** button in Fizgig's sidebar opens it. Drag a dataset folder in from your desktop,
download finished LoRAs from `output_loras/` the same way. No terminal, no SSH keys.

<p align="center"><img src="../docs/assets/screenshots/file_manager.png" alt="The pod's file manager: a training folder's pictures and captions" width="800"></p>

Prefer a terminal? `runpodctl` is preinstalled — `runpodctl send <path>` on the pod, then
`runpodctl receive <code>` on your machine. `scp` and `rsync` over SSH work too, and rsync is the
better bet for a large dataset since it resumes.

## Where things live

```
/workspace/datasets/      your training images (one folder per LoRA)
/workspace/models/        the weights
/workspace/output_loras/  finished LoRAs
```

Everything under `/workspace` persists. Anything outside it is wiped when the pod stops.

## Stopping the pod when a run finishes

A rented GPU bills by the hour, so a run that ends at 4am keeps billing until you notice.
**Preferences → RunPod → Stop this pod when a training run finishes** fixes that. You get a
two-minute countdown you can cancel, and it never fires after a Pause, a Stop or a failure — those
are exactly the times you want the machine alive.

It needs an API key, pasted into that same panel. Make one at **RunPod → Settings → API Keys**; the
key RunPod gives a pod automatically is pod-scoped and cannot stop pods, which is a RunPod
limitation rather than a Fizgig one. It's stored on your volume, not in any template.

## Settings

Environment variables, set on the deploy screen under **Edit Template**:

| Variable | Values | |
|---|---|---|
| `FIZGIG_PASSWORD` | your choice (not a very common one) | Fizgig *and* the file manager. Generated on the first start if unset, then kept. (`VNC_PASSWORD`, the classic template's name, works too.) |
| `HF_TOKEN` | `hf_…` | Only needed for Klein and Flux 3 Image Klein, which are gated. Krea 2 needs nothing. |
| `FETCH_MODELS` | `krea2`, `klein`, `flux3`, `minimax`, `tools` — comma-separated | Download at boot instead of clicking the button in Preferences. `minimax` includes the Circlestone and both Ostris training adapters. `tools` is the Florence-2 captioner, the EN→ZH translator for bilingual captions, and the face model the Look Filter uses. |
| `FIZGIG_REF` | branch or tag | Which Fizgig to run. Defaults to `master`, so the app updates itself at every pod start. |

Nothing is compulsory — the defaults are the intended setup, and everything here can be done from
inside the app instead.

Two more exist for unusual cases: `FETCH_MODELS_EXTRA` passes extra flags to the downloader, and `FIZGIG_REPO` points the pod at a fork.

## The classic template (remote desktop)

For a while there are two templates. The one above is the new Fizgig in a browser tab. **[Fizgig Classic v7.x](https://console.runpod.io/deploy?type=GPU&gpu=RTX+5090&count=1&template=faoq8ed6um&ref=vkb387ep)** is the previous pod: the classic desktop app in a remote desktop on port 6080, for anyone partway through a big job who wants to finish it on what they know.

- **Logging in:** port **6080**, user `fizgig`, and the pod's `VNC_PASSWORD` (generated and printed in the log if you didn't set one; on Classic it changes each time the pod starts). The file manager is on 8080 as above, and the new web page on 8081 with the same password.
- **First run:** Preferences → **⬇ Download models for me**, drag a dataset into `/workspace/datasets` on port 8080, then Start tab → **Browse** and **Training → Start**.
- **Settings:** the same as above, with `VNC_PASSWORD` for the password and `SCREEN_W` / `SCREEN_H` for the desktop's starting size (1600×1400; it then resizes to your browser window).
- **Moving over:** the two use the same `/workspace` layout, so a volume from a Classic pod works on the new one. Models, datasets, LoRAs and run history carry across.
- **Pods you already have** keep the image they were made with and carry on as Classic pods. Deploy the new template when you want the new one.

## If something's wrong

The **pod log** is the first place to look — every step is narrated there, including storage and the
password.

- **Both links dead just after deploying** — it's still downloading the image. Wait for the
  "Ready" banner in the log.
- **Storage shows ~25 GB** — the volume didn't mount. Check the mount path is `/workspace`.
- **Downloads fail with "no space left"** — same cause: models are landing on container disk.
- **Your models vanished** — the pod was *terminated* rather than *stopped*. A Volume Disk goes
  with its pod; stop it instead, or use a Network Volume if you need to terminate.
- **Restarts every few seconds** — `/workspace` is a Global
  Volume, which git can't clone onto (see Storage above). Switch it for a Volume Disk or a regional
  Network Volume.

Fizgig's own version and the image's are both shown in **Preferences → RunPod**; quote both if you
report a problem, since the app updates itself independently of the image.
