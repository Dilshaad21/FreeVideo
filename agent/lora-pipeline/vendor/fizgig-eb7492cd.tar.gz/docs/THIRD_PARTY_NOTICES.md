# Third-Party Notices

Fizgig is licensed under the Apache License, Version 2.0 (see `LICENSE`).

It includes code derived from the third-party projects listed below. Each
component remains under its upstream license. Permissive components (Apache-2.0,
MIT) are compatible with Fizgig's Apache-2.0 license; where those files were
modified, Fizgig's changes are released under Apache-2.0. Copyleft components
(GPL-3.0) are marked separately and stay under GPL-3.0 — see the comfyui-rocm
and ComfyUI sections below.

---

## musubi-tuner — Apache License 2.0

Upstream: https://github.com/kohya-ss/musubi-tuner
Copyright the musubi-tuner authors (kohya-ss and contributors).

The following Krea 2 modules are adapted (and modified) from musubi-tuner:

- `src/fizgig/krea2/offloading.py` (block-swap offloader)
- `src/fizgig/krea2/fp8_optimization_utils.py` (fp8 quantization)
- `src/fizgig/krea2/safetensors_utils.py` (mmap safetensors I/O)
- `src/fizgig/krea2/lora_utils.py`
- `src/fizgig/krea2/attention.py` (attention dispatch)
- `src/fizgig/krea2/vae_loader.py` (Qwen-Image VAE loader/converter)
- training hooks (gradient checkpointing, block-swap wiring) in
  `src/fizgig/krea2/model.py` and the flow-matching training recipe in
  `src/fizgig/krea2/trainer.py`

Licensed under the Apache License, Version 2.0:
http://www.apache.org/licenses/LICENSE-2.0

---

## sd-scripts — Apache License 2.0

Upstream: https://github.com/kohya-ss/sd-scripts
Copyright the sd-scripts authors (kohya-ss and contributors); the model code it
carries is NVIDIA CORPORATION & AFFILIATES' (Apache-2.0).

- `src/fizgig/anima/model.py` (Anima's DiT: Cosmos-Predict2 MiniTrainDIT and the
  LLM adapter), adapted from `library/anima_models.py` and modified: PyTorch SDPA
  attention, plain non-reentrant gradient checkpointing, no block swap / CPU
  offload.

Licensed under the Apache License, Version 2.0:
http://www.apache.org/licenses/LICENSE-2.0

---

## ai-toolkit (Ostris, LLC) — MIT License

Upstream: https://github.com/ostris/ai-toolkit

The Krea 2 single-stream MMDiT backbone (`src/fizgig/krea2/model.py`) and the
functional flow-matching sampler (`src/fizgig/krea2/sampling.py`) are ported
from ai-toolkit's `extensions_built_in/diffusion_models/{krea2,flux2}/src`,
then adapted for Fizgig.

The Automagic v3 optimizer (`src/fizgig/training/automagic3.py`) is kept
byte-for-byte as upstream's `toolkit/optimizers/automagic3.py`, under a Fizgig
header describing how it is constructed. Offered as an optimizer choice on the
MiniMax H3 and Krea 2 LoRA paths.

```
MIT License

Copyright (c) 2024 Ostris, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## FLUX (Black Forest Labs) — Apache License 2.0

Upstream: https://github.com/black-forest-labs/flux

The Klein 9B DiT (`src/fizgig/klein/model.py`) is a Fizgig-native implementation
based on the FLUX reference model code. Licensed under the Apache License,
Version 2.0. (Model weights are distributed separately under their own license —
see "Note on model weights" below.)

---

## FLUX 3 Image Klein (Black Forest Labs) — Apache License 2.0

Upstream: https://github.com/black-forest-labs/flux-3-image-klein

`src/fizgig/flux3/` (the DiT, autoencoder, text-encoder wrapper and sampler) is adapted from the FLUX 3 Image Klein reference implementation; its licence is in `src/fizgig/flux3/LICENSE`. Licensed under the Apache License, Version 2.0. (Model weights are distributed separately under the FLUX Kommunity License — see "Note on model weights" below.)

---

## Diffusers / Qwen-Image VAE — Apache License 2.0

Upstream: https://github.com/huggingface/diffusers

`src/fizgig/krea2/vae.py` is copied and modified from the Diffusers
`AutoencoderKLQwenImage` implementation.
Copyright 2025 The Qwen-Image Team, Wan Team, and The HuggingFace Team.
All rights reserved. Licensed under the Apache License, Version 2.0.

---

## Z-Image (Tongyi-MAI / Alibaba) — Apache License 2.0

Upstream: https://github.com/Tongyi-MAI/Z-Image

`src/fizgig/zimage/model.py` (the S3-DiT transformer) and `src/fizgig/zimage/pipeline.py` (text encoding and
sampling) are adapted from the Z-Image reference implementation (`src/zimage/transformer.py`,
`src/zimage/pipeline.py`). Copyright 2025 Alibaba Z-Image Team. Licensed under the Apache License, Version 2.0.
Fizgig's changes are described in each file's header. (Model weights are distributed separately under their own
license — see "Note on model weights" below.)

---

## comfyui-rocm — GNU General Public License v3.0

Upstream: https://github.com/patientx/comfyui-rocm
Copyright the comfyui-rocm authors (patientx and contributors).

comfyui-rocm is a Windows ROCm build of ComfyUI. Fizgig's AMD ROCm Windows
installer uses code from that project as follows:

- `src/install/detect_gpu.py` — copied verbatim from comfyui-rocm's `detect_gpu.py`
  (AMD GPU → gfx architecture detection on Windows). **Unmodified.** This file
  is **GPL-3.0 only**; it is not relicensed under Apache-2.0.
- `install_fizgig_rocm.bat` — Fizgig-authored installer that **calls**
  `detect_gpu.py` and follows the same ROCm-wheel install patterns as
  comfyui-rocm's `install.bat` (adapted for Fizgig's venv and
  requirements). The batch file itself is Apache-2.0; the bundled
  `detect_gpu.py` remains GPL-3.0.
- `Launch Fizgig AMD.bat` / `launch_fizgig_amd.sh` — Fizgig-authored launchers.
  Legacy RDNA1/2 SDP overrides, aotriton gating, and MIOpen/rocBLAS tensile
  DB path setup are adapted from comfyui-rocm's `comfyui-rocm.bat`. The
  launchers themselves are Apache-2.0; Windows detection still goes through
  the GPL-3.0 `detect_gpu.py` above.

`detect_gpu.py` is free software: you may redistribute and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later
version. A copy of the GPL-3.0 text is available at
https://www.gnu.org/licenses/gpl-3.0.html and in comfyui-rocm's `LICENSE` file.

To receive source for `detect_gpu.py`, use this repository or the upstream
comfyui-rocm repository linked above.

---

## ComfyUI — GNU General Public License v3.0

Upstream: https://github.com/comfyanonymous/ComfyUI
Copyright (C) comfyanonymous and the ComfyUI contributors.

Fizgig's MiniMax H3 support includes code derived from ComfyUI's MiniMax H3
implementation. These files are **GPL-3.0**; they are not relicensed under
Apache-2.0, and each carries a header saying so:

- `src/fizgig/minimax/model.py` — the H3 DiT, ported from
  `comfy/ldm/minimax/model.py` (ComfyUI's plumbing replaced by plain PyTorch).
- `src/fizgig/minimax/vae.py` — the H3 video VAE, ported from
  `comfy/ldm/minimax/vae.py`.
- `src/fizgig/minimax/audio_vae.py` — the H3 audio VAE, ported from
  `comfy/ldm/minimax/audio_vae.py`.
- `src/fizgig/minimax/reference.py` — the reference-to-video conditioning,
  transcribed from `comfy_extras/nodes_minimax_h3.py`
  (`MiniMaxH3ReferenceToVideo`).
- `src/fizgig/minimax/sampling.py` — the `_res_multistep_coeffs` function only,
  ported from `comfy/k_diffusion/sampling.py` (`res_multistep`). The rest of
  that file is Fizgig's own and Apache-2.0.

These files are free software: you may redistribute and/or modify them under
the terms of the GNU General Public License v3.0. A copy of the GPL-3.0 text is
available at https://www.gnu.org/licenses/gpl-3.0.html and in ComfyUI's
`LICENSE` file. Their source is this repository.

The MiniMax H3 model weights are not part of this code; MiniMax's own licence
applies to them (see the note on model weights below).

---

## bitsandbytes Windows ROCm wheel (0xDELUXA) — downloaded at install time

The Windows AMD installer (`install_fizgig_rocm.bat`) downloads a **pinned**
community bitsandbytes wheel from:

https://github.com/0xDELUXA/bitsandbytes_win_rocm

That wheel is **not** built by AMD or Fizgig; it is only fetched on the AMD
install path. Official ROCm PyTorch wheels similarly come from AMD's nightly
index (`https://rocm.nightlies.amd.com/whl-multi-arch/`), also disclosed by the
installer before download.

---

## QR Code Generator for JavaScript (Kazuhiko Arase) — MIT License

`src/fizgig/web/static/qrcode.js` is qrcode-generator 1.4.4, unchanged: <https://github.com/kazuhikoarase/qrcode-generator>. It draws the Start tab's **Open on your phone** code.

```
Copyright (c) 2009 Kazuhiko Arase

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

The word "QR Code" is a registered trademark of DENSO WAVE INCORPORATED.

## Note on model weights

The third-party notices above cover **source code** only. Krea 2 / FLUX.2 model
weights, the Qwen-Image VAE weights, the Qwen3-VL text-encoder weights, and the
MiniMax H3 training adapters (circlestone-labs and Ostris) are distributed by their respective publishers under their own model licenses, which
the user accepts when downloading them. Fizgig does not redistribute any model
weights.
